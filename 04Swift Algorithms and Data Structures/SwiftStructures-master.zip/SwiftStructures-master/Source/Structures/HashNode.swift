//
//  HashNode.swift
//  SwiftStructures
//
//  Created by Wayne Bishop on 10/29/14.
//  Copyright (c) 2014 Arbutus Software Inc. All rights reserved.
//

import Foundation

class HashNode {
    
    var firstname: String!
    var lastname: String!
    var next: HashNode!
    
}